
  # Video Analytics Dashboard

  This is a code bundle for Video Analytics Dashboard. The original project is available at https://www.figma.com/design/zBUiqqM4GR0hT80d2smWHm/Video-Analytics-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  