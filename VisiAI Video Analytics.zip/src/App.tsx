import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { LiveView } from './components/LiveView';
import { AlertsPanel } from './components/AlertsPanel';
import { Analytics } from './components/Analytics';
import { CameraManagement } from './components/CameraManagement';
import { CameraIntegration } from './components/CameraIntegration';
import { Navigation } from './components/Navigation';
import { Button } from './components/ui/button';
import { Toaster } from './components/ui/sonner';
import { Sun, Moon } from 'lucide-react';

export type Screen = 'dashboard' | 'live' | 'alerts' | 'analytics' | 'cameras' | 'integration';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);

  const handleNavigate = (screen: Screen) => {
    console.log('App: Navigating to screen:', screen);
    setCurrentScreen(screen);
  };

  const renderScreen = () => {
    console.log('App: Rendering screen:', currentScreen);
    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard onCameraSelect={(id) => {
          setSelectedCamera(id);
          setCurrentScreen('live');
        }} />;
      case 'live':
        return <LiveView cameraId={selectedCamera} onBack={() => setCurrentScreen('dashboard')} />;
      case 'alerts':
        return <AlertsPanel />;
      case 'analytics':
        return <Analytics />;
      case 'cameras':
        return <CameraManagement />;
      case 'integration':
        return <CameraIntegration />;
      default:
        return <Dashboard onCameraSelect={(id) => {
          setSelectedCamera(id);
          setCurrentScreen('live');
        }} />;
    }
  };

  return (
    <div className={`${isDarkMode ? 'dark' : ''} min-h-screen bg-background text-foreground flex`}>
      <Navigation 
        currentScreen={currentScreen} 
        onNavigate={handleNavigate}
      />
      <main className="flex-1 overflow-auto">
        <div className="relative min-h-full">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="fixed top-4 right-4 z-50"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          {renderScreen()}
        </div>
      </main>
      <Toaster />
    </div>
  );
}