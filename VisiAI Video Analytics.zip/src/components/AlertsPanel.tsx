import { useState } from 'react';
import { Filter, Search, Download, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { mockAlerts } from '../data/mockData';
import type { Alert } from '../types';

export function AlertsPanel() {
  const [alerts] = useState<Alert[]>(mockAlerts);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);

  const filteredAlerts = alerts.filter(alert => {
    const matchesSearch = alert.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         alert.cameraName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
    const matchesType = typeFilter === 'all' || alert.type === typeFilter;
    return matchesSearch && matchesSeverity && matchesType;
  });

  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const warningCount = alerts.filter(a => a.severity === 'warning').length;

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="p-6 border-b border-border bg-card">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-semibold mb-2">Alerts & Events</h1>
            <p className="text-muted-foreground">Monitor and manage security events</p>
          </div>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <Card className="bg-red-500/10 border-red-500/20">
            <CardContent className="pt-4">
              <div className="text-2xl font-bold text-red-500">{criticalCount}</div>
              <p className="text-sm text-red-400">Critical</p>
            </CardContent>
          </Card>
          <Card className="bg-yellow-500/10 border-yellow-500/20">
            <CardContent className="pt-4">
              <div className="text-2xl font-bold text-yellow-500">{warningCount}</div>
              <p className="text-sm text-yellow-400">Warning</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-500/10 border-blue-500/20">
            <CardContent className="pt-4">
              <div className="text-2xl font-bold text-blue-500">{alerts.length - criticalCount - warningCount}</div>
              <p className="text-sm text-blue-400">Info</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search alerts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="info">Info</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="ppe">PPE</SelectItem>
              <SelectItem value="intrusion">Intrusion</SelectItem>
              <SelectItem value="loitering">Loitering</SelectItem>
              <SelectItem value="face">Face</SelectItem>
              <SelectItem value="crowd">Crowd</SelectItem>
              <SelectItem value="behavior">Behavior</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Alerts List */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-3">
            {filteredAlerts.map((alert) => (
              <Card
                key={alert.id}
                className={`cursor-pointer transition-colors border-border ${
                  selectedAlert?.id === alert.id ? 'bg-accent' : 'bg-card hover:bg-accent/50'
                }`}
                onClick={() => setSelectedAlert(alert)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Thumbnail */}
                    <img
                      src={alert.thumbnail}
                      alt={alert.message}
                      className="w-24 h-18 rounded object-cover flex-shrink-0"
                    />

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge
                            variant={
                              alert.severity === 'critical'
                                ? 'destructive'
                                : alert.severity === 'warning'
                                ? 'default'
                                : 'secondary'
                            }
                          >
                            {alert.severity}
                          </Badge>
                          <Badge variant="outline">{alert.type.toUpperCase()}</Badge>
                          <span className="font-semibold">{alert.message}</span>
                        </div>
                        <div className="text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(alert.timestamp).toLocaleString()}
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>📹 {alert.cameraName}</span>
                        {alert.confidence && (
                          <span>Confidence: {Math.round(alert.confidence * 100)}%</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredAlerts.length === 0 && (
            <div className="text-center py-12">
              <Filter className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No alerts match your filters</p>
            </div>
          )}
        </div>

        {/* Alert Detail Panel */}
        {selectedAlert && (
          <div className="w-96 border-l border-border bg-card overflow-y-auto">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <h3 className="font-semibold">Alert Details</h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedAlert(null)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="p-4 space-y-4">
              {/* Image */}
              <img
                src={selectedAlert.thumbnail}
                alt={selectedAlert.message}
                className="w-full rounded-lg"
              />

              {/* Info */}
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-muted-foreground">Event Type</label>
                  <div className="font-medium">{selectedAlert.message}</div>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">Camera</label>
                  <div className="font-medium">{selectedAlert.cameraName}</div>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">Timestamp</label>
                  <div className="font-medium">
                    {new Date(selectedAlert.timestamp).toLocaleString()}
                  </div>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">Severity</label>
                  <div>
                    <Badge
                      variant={
                        selectedAlert.severity === 'critical'
                          ? 'destructive'
                          : selectedAlert.severity === 'warning'
                          ? 'default'
                          : 'secondary'
                      }
                    >
                      {selectedAlert.severity}
                    </Badge>
                  </div>
                </div>

                {selectedAlert.confidence && (
                  <div>
                    <label className="text-sm text-muted-foreground">Confidence</label>
                    <div className="font-medium">
                      {Math.round(selectedAlert.confidence * 100)}%
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="pt-4 border-t border-border space-y-2">
                <Button className="w-full" variant="default">
                  Mark as Resolved
                </Button>
                <Button className="w-full" variant="outline">
                  View Camera
                </Button>
                <Button className="w-full" variant="outline">
                  Download Snapshot
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
