import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Calendar } from 'lucide-react';
import { Button } from './ui/button';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export function Analytics() {
  // Mock data for charts
  const eventTimeData = [
    { time: '00:00', events: 4 },
    { time: '04:00', events: 2 },
    { time: '08:00', events: 12 },
    { time: '12:00', events: 18 },
    { time: '16:00', events: 15 },
    { time: '20:00', events: 8 },
  ];

  const ppeComplianceData = [
    { date: 'Mon', compliance: 92 },
    { date: 'Tue', compliance: 88 },
    { date: 'Wed', compliance: 95 },
    { date: 'Thu', compliance: 90 },
    { date: 'Fri', compliance: 85 },
    { date: 'Sat', compliance: 94 },
    { date: 'Sun', compliance: 96 },
  ];

  const eventTypeData = [
    { name: 'PPE Violations', value: 35, color: '#ef4444' },
    { name: 'Intrusion', value: 25, color: '#f59e0b' },
    { name: 'Loitering', value: 20, color: '#3b82f6' },
    { name: 'Face Detection', value: 15, color: '#10b981' },
    { name: 'Other', value: 5, color: '#6366f1' },
  ];

  const zoneActivityData = [
    { zone: 'Entrance', incidents: 45 },
    { zone: 'Warehouse', incidents: 68 },
    { zone: 'Loading Dock', incidents: 32 },
    { zone: 'Parking', incidents: 15 },
    { zone: 'Office', incidents: 22 },
  ];

  const occupancyData = [
    { time: '08:00', occupancy: 45 },
    { time: '10:00', occupancy: 78 },
    { time: '12:00', occupancy: 92 },
    { time: '14:00', occupancy: 85 },
    { time: '16:00', occupancy: 70 },
    { time: '18:00', occupancy: 35 },
  ];

  return (
    <div className="p-6 space-y-6 bg-background">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold mb-2">Analytics & Reports</h1>
          <p className="text-muted-foreground">Insights and compliance metrics</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Calendar className="w-4 h-4 mr-2" />
            Last 7 Days
          </Button>
          <Button variant="default">Export Report</Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Events
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">342</div>
            <p className="text-xs text-green-500 mt-1">↓ 12% from last week</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              PPE Compliance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">91.2%</div>
            <p className="text-xs text-green-500 mt-1">↑ 3% from last week</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Avg Response Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.4m</div>
            <p className="text-xs text-green-500 mt-1">↓ 18s from last week</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Critical Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">23</div>
            <p className="text-xs text-red-500 mt-1">↑ 5 from last week</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Event Timeline */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Event Count Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={eventTimeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="time" stroke="#888" />
                <YAxis stroke="#888" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f1f1f',
                    border: '1px solid #333',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="events"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Event Distribution */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Event Type Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={eventTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {eventTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f1f1f',
                    border: '1px solid #333',
                    borderRadius: '8px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PPE Compliance */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>PPE Compliance Percentage</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={ppeComplianceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" stroke="#888" />
                <YAxis stroke="#888" domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f1f1f',
                    border: '1px solid #333',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Bar dataKey="compliance" fill="#10b981" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Zone Activity */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Intrusion Frequency by Zone</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={zoneActivityData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis type="number" stroke="#888" />
                <YAxis dataKey="zone" type="category" stroke="#888" width={100} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f1f1f',
                    border: '1px solid #333',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Bar dataKey="incidents" fill="#f59e0b" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Occupancy Trends */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Occupancy Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={occupancyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="time" stroke="#888" />
              <YAxis stroke="#888" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1f1f1f',
                  border: '1px solid #333',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="occupancy"
                stroke="#8b5cf6"
                strokeWidth={2}
                dot={{ fill: '#8b5cf6', r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Top Violations Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Top Violations This Week</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                    Violation Type
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                    Count
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                    Most Common Zone
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">
                    Trend
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border">
                  <td className="py-3 px-4">Helmet Missing</td>
                  <td className="py-3 px-4 font-medium">24</td>
                  <td className="py-3 px-4">Warehouse</td>
                  <td className="py-3 px-4 text-red-500">↑ 15%</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="py-3 px-4">Unauthorized Access</td>
                  <td className="py-3 px-4 font-medium">18</td>
                  <td className="py-3 px-4">Server Room</td>
                  <td className="py-3 px-4 text-green-500">↓ 8%</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="py-3 px-4">Safety Vest Missing</td>
                  <td className="py-3 px-4 font-medium">15</td>
                  <td className="py-3 px-4">Loading Dock</td>
                  <td className="py-3 px-4 text-green-500">↓ 12%</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="py-3 px-4">Loitering</td>
                  <td className="py-3 px-4 font-medium">12</td>
                  <td className="py-3 px-4">Parking Area</td>
                  <td className="py-3 px-4 text-yellow-500">→ 0%</td>
                </tr>
                <tr>
                  <td className="py-3 px-4">High Occupancy</td>
                  <td className="py-3 px-4 font-medium">8</td>
                  <td className="py-3 px-4">Office Corridor</td>
                  <td className="py-3 px-4 text-red-500">↑ 25%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
