import { useState } from 'react';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Badge } from './ui/badge';
import { CheckCircle2, Wifi, Usb } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface CameraConfig {
  id: string;
  name: string;
  type: 'ip' | 'usb';
  ipAddress?: string;
  port?: string;
  comPort?: string;
  model: string;
  status: 'configured' | 'pending';
  configuredAt: Date;
}

export function CameraIntegration() {
  const [cameraType, setCameraType] = useState<'ip' | 'usb'>('ip');
  const [cameraName, setCameraName] = useState('');
  const [ipAddress, setIpAddress] = useState('');
  const [port, setPort] = useState('8554');
  const [comPort, setComPort] = useState('');
  const [selectedModel, setSelectedModel] = useState('');
  const [configuredCameras, setConfiguredCameras] = useState<CameraConfig[]>([
    {
      id: '1',
      name: 'Entrance Camera',
      type: 'ip',
      ipAddress: '192.168.1.101',
      port: '8554',
      model: 'Face Recognition',
      status: 'configured',
      configuredAt: new Date('2026-02-15T10:30:00'),
    },
    {
      id: '2',
      name: 'Warehouse USB Cam',
      type: 'usb',
      comPort: 'COM3',
      model: 'PPE Detection',
      status: 'configured',
      configuredAt: new Date('2026-02-14T14:20:00'),
    },
  ]);

  const detectionModels = [
    { value: 'face', label: 'Face Recognition' },
    { value: 'ppe', label: 'PPE Detection' },
    { value: 'intrusion', label: 'Intrusion Detection' },
    { value: 'loitering', label: 'Loitering Detection' },
    { value: 'crowd', label: 'Crowd Density Analysis' },
    { value: 'behavior', label: 'Behavior Analysis' },
  ];

  const comPorts = ['COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6'];

  const handleSaveConfiguration = () => {
    if (!cameraName || !selectedModel) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (cameraType === 'ip' && !ipAddress) {
      toast.error('Please enter IP address');
      return;
    }

    if (cameraType === 'usb' && !comPort) {
      toast.error('Please select COM port');
      return;
    }

    const newCamera: CameraConfig = {
      id: String(configuredCameras.length + 1),
      name: cameraName,
      type: cameraType,
      ...(cameraType === 'ip' ? { ipAddress, port } : { comPort }),
      model: detectionModels.find(m => m.value === selectedModel)?.label || '',
      status: 'configured',
      configuredAt: new Date(),
    };

    setConfiguredCameras([...configuredCameras, newCamera]);
    
    // Reset form
    setCameraName('');
    setIpAddress('');
    setPort('8554');
    setComPort('');
    setSelectedModel('');
    
    toast.success('Camera configuration saved successfully!');
  };

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-semibold mb-2">Camera Integration</h1>
        <p className="text-muted-foreground">Configure and integrate cameras with AI detection models</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Form */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-6">Add New Camera</h2>
          
          {/* Camera Name */}
          <div className="mb-6">
            <Label htmlFor="camera-name" className="mb-2 block">Camera Name *</Label>
            <Input
              id="camera-name"
              placeholder="e.g., Main Entrance Camera"
              value={cameraName}
              onChange={(e) => setCameraName(e.target.value)}
            />
          </div>

          {/* Camera Type Selection */}
          <div className="mb-6">
            <Label className="mb-3 block">Camera Type *</Label>
            <RadioGroup value={cameraType} onValueChange={(value) => setCameraType(value as 'ip' | 'usb')}>
              <div className="flex gap-4">
                <div className="flex items-center space-x-2 flex-1">
                  <RadioGroupItem value="ip" id="ip" />
                  <Label htmlFor="ip" className="flex items-center gap-2 cursor-pointer">
                    <Wifi className="w-4 h-4" />
                    IP-based Camera
                  </Label>
                </div>
                <div className="flex items-center space-x-2 flex-1">
                  <RadioGroupItem value="usb" id="usb" />
                  <Label htmlFor="usb" className="flex items-center gap-2 cursor-pointer">
                    <Usb className="w-4 h-4" />
                    USB Camera
                  </Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* IP-based Configuration */}
          {cameraType === 'ip' && (
            <div className="space-y-4 mb-6">
              <div>
                <Label htmlFor="ip-address" className="mb-2 block">IP Address *</Label>
                <Input
                  id="ip-address"
                  placeholder="192.168.1.100"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="port" className="mb-2 block">Port (Optional)</Label>
                <Input
                  id="port"
                  placeholder="8554"
                  value={port}
                  onChange={(e) => setPort(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* USB Configuration */}
          {cameraType === 'usb' && (
            <div className="mb-6">
              <Label htmlFor="com-port" className="mb-2 block">COM Port *</Label>
              <Select value={comPort} onValueChange={setComPort}>
                <SelectTrigger id="com-port">
                  <SelectValue placeholder="Select COM port" />
                </SelectTrigger>
                <SelectContent>
                  {comPorts.map((port) => (
                    <SelectItem key={port} value={port}>{port}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Model Selection */}
          <div className="mb-6">
            <Label htmlFor="model" className="mb-2 block">Detection Model *</Label>
            <Select value={selectedModel} onValueChange={setSelectedModel}>
              <SelectTrigger id="model">
                <SelectValue placeholder="Select detection model" />
              </SelectTrigger>
              <SelectContent>
                {detectionModels.map((model) => (
                  <SelectItem key={model.value} value={model.value}>
                    {model.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleSaveConfiguration} className="w-full">
            Save Configuration
          </Button>
        </Card>

        {/* Configured Cameras List */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-6">Configured Cameras</h2>
          
          <div className="space-y-3">
            {configuredCameras.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No cameras configured yet</p>
            ) : (
              configuredCameras.map((camera) => (
                <Card key={camera.id} className="p-4 bg-muted/30">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-blue-600/10 rounded-lg flex items-center justify-center mt-1">
                        {camera.type === 'ip' ? (
                          <Wifi className="w-5 h-5 text-blue-600" />
                        ) : (
                          <Usb className="w-5 h-5 text-blue-600" />
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">{camera.name}</h3>
                        <div className="text-sm text-muted-foreground space-y-1">
                          {camera.type === 'ip' ? (
                            <>
                              <div>IP: {camera.ipAddress}</div>
                              {camera.port && <div>Port: {camera.port}</div>}
                            </>
                          ) : (
                            <div>Port: {camera.comPort}</div>
                          )}
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="secondary" className="text-xs">
                              {camera.model}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Configured: {camera.configuredAt.toLocaleString()}
                  </div>
                </Card>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
