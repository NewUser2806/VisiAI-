import { useState } from 'react';
import { Plus, Edit, Trash2, Video, MapPin } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from './ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { mockCameras, mockZones } from '../data/mockData';
import type { Camera, Zone } from '../types';

export function CameraManagement() {
  const [cameras, setCameras] = useState<Camera[]>(mockCameras);
  const [zones, setZones] = useState<Zone[]>(mockZones);
  const [isAddCameraOpen, setIsAddCameraOpen] = useState(false);
  const [isAddZoneOpen, setIsAddZoneOpen] = useState(false);
  const [editingCamera, setEditingCamera] = useState<Camera | null>(null);

  // Form states
  const [newCamera, setNewCamera] = useState({
    name: '',
    location: '',
    rtspUrl: '',
    zone: '',
  });

  const [newZone, setNewZone] = useState({
    name: '',
    type: 'monitored' as 'restricted' | 'monitored' | 'public',
  });

  const handleAddCamera = () => {
    if (newCamera.name && newCamera.location && newCamera.rtspUrl) {
      const camera: Camera = {
        id: `cam-${Date.now()}`,
        name: newCamera.name,
        location: newCamera.location,
        status: 'active',
        rtspUrl: newCamera.rtspUrl,
        zone: newCamera.zone || undefined,
        thumbnail: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop',
      };
      setCameras([...cameras, camera]);
      setNewCamera({ name: '', location: '', rtspUrl: '', zone: '' });
      setIsAddCameraOpen(false);
    }
  };

  const handleAddZone = () => {
    if (newZone.name) {
      const zone: Zone = {
        id: `zone-${Date.now()}`,
        name: newZone.name,
        type: newZone.type,
        cameras: [],
      };
      setZones([...zones, zone]);
      setNewZone({ name: '', type: 'monitored' });
      setIsAddZoneOpen(false);
    }
  };

  const handleDeleteCamera = (id: string) => {
    setCameras(cameras.filter(c => c.id !== id));
  };

  const handleDeleteZone = (id: string) => {
    setZones(zones.filter(z => z.id !== id));
  };

  return (
    <div className="p-6 space-y-6 bg-background">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold mb-2">Camera & Zone Management</h1>
          <p className="text-muted-foreground">Configure cameras and security zones</p>
        </div>
      </div>

      <Tabs defaultValue="cameras" className="w-full">
        <TabsList>
          <TabsTrigger value="cameras">Cameras</TabsTrigger>
          <TabsTrigger value="zones">Zones</TabsTrigger>
        </TabsList>

        {/* Cameras Tab */}
        <TabsContent value="cameras" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              {cameras.length} cameras configured
            </p>
            <Dialog open={isAddCameraOpen} onOpenChange={setIsAddCameraOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Camera
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Camera</DialogTitle>
                  <DialogDescription>
                    Configure a new camera for monitoring
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="camera-name">Camera Name</Label>
                    <Input
                      id="camera-name"
                      placeholder="e.g., Entrance Camera 1"
                      value={newCamera.name}
                      onChange={(e) => setNewCamera({ ...newCamera, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="camera-location">Location</Label>
                    <Input
                      id="camera-location"
                      placeholder="e.g., Main Building - Floor 1"
                      value={newCamera.location}
                      onChange={(e) => setNewCamera({ ...newCamera, location: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="camera-rtsp">RTSP URL</Label>
                    <Input
                      id="camera-rtsp"
                      placeholder="rtsp://192.168.1.100:554/stream"
                      value={newCamera.rtspUrl}
                      onChange={(e) => setNewCamera({ ...newCamera, rtspUrl: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="camera-zone">Assign to Zone</Label>
                    <Select
                      value={newCamera.zone}
                      onValueChange={(value) => setNewCamera({ ...newCamera, zone: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select zone" />
                      </SelectTrigger>
                      <SelectContent>
                        {zones.map((zone) => (
                          <SelectItem key={zone.id} value={zone.id}>
                            {zone.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddCameraOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddCamera}>Add Camera</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cameras.map((camera) => (
              <Card key={camera.id} className="bg-card border-border">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Video className="w-4 h-4 text-muted-foreground" />
                      <CardTitle className="text-base">{camera.name}</CardTitle>
                    </div>
                    <Badge variant={camera.status === 'active' ? 'default' : 'destructive'}>
                      {camera.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="aspect-video bg-secondary rounded-lg overflow-hidden">
                    <img
                      src={camera.thumbnail}
                      alt={camera.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-3 h-3" />
                      <span>{camera.location}</span>
                    </div>
                    {camera.zone && (
                      <div className="text-muted-foreground">
                        Zone: {zones.find(z => z.id === camera.zone)?.name || 'Unknown'}
                      </div>
                    )}
                    <div className="text-xs text-muted-foreground font-mono truncate">
                      {camera.rtspUrl}
                    </div>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-destructive"
                      onClick={() => handleDeleteCamera(camera.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Zones Tab */}
        <TabsContent value="zones" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              {zones.length} zones configured
            </p>
            <Dialog open={isAddZoneOpen} onOpenChange={setIsAddZoneOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Zone
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Zone</DialogTitle>
                  <DialogDescription>
                    Create a new security zone for monitoring
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="zone-name">Zone Name</Label>
                    <Input
                      id="zone-name"
                      placeholder="e.g., Warehouse Area"
                      value={newZone.name}
                      onChange={(e) => setNewZone({ ...newZone, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="zone-type">Zone Type</Label>
                    <Select
                      value={newZone.type}
                      onValueChange={(value: any) => setNewZone({ ...newZone, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="restricted">Restricted</SelectItem>
                        <SelectItem value="monitored">Monitored</SelectItem>
                        <SelectItem value="public">Public</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddZoneOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddZone}>Add Zone</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {zones.map((zone) => {
              const zoneCameras = cameras.filter(c => c.zone === zone.id);
              return (
                <Card key={zone.id} className="bg-card border-border">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-base">{zone.name}</CardTitle>
                      <Badge
                        variant={
                          zone.type === 'restricted'
                            ? 'destructive'
                            : zone.type === 'monitored'
                            ? 'default'
                            : 'secondary'
                        }
                      >
                        {zone.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">
                        {zoneCameras.length} camera{zoneCameras.length !== 1 ? 's' : ''} assigned
                      </div>
                      {zoneCameras.length > 0 && (
                        <div className="space-y-1">
                          {zoneCameras.map((cam) => (
                            <div
                              key={cam.id}
                              className="text-xs bg-secondary/50 px-2 py-1 rounded flex items-center gap-2"
                            >
                              <Video className="w-3 h-3" />
                              {cam.name}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2 pt-2 border-t border-border">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="w-3 h-3 mr-1" />
                        Edit Rules
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-destructive"
                        onClick={() => handleDeleteZone(zone.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Zone Rules */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Zone Rules & Restrictions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 bg-red-500 rounded-full" />
                <h4 className="font-medium">Restricted Zones</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                High-security areas requiring authorization. Triggers critical alerts on unauthorized access.
              </p>
            </div>
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                <h4 className="font-medium">Monitored Zones</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Active monitoring areas with PPE compliance and safety checks enabled.
              </p>
            </div>
            <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full" />
                <h4 className="font-medium">Public Zones</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Low-risk areas with basic occupancy and behavior monitoring.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
