import { AlertTriangle, Shield, Users, Activity } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { mockCameras, mockAlerts, mockModules } from '../data/mockData';

interface DashboardProps {
  onCameraSelect: (cameraId: string) => void;
}

export function Dashboard({ onCameraSelect }: DashboardProps) {
  const activeCameras = mockCameras.filter(c => c.status === 'active').length;
  const offlineCameras = mockCameras.filter(c => c.status === 'offline').length;
  const criticalAlerts = mockAlerts.filter(a => a.severity === 'critical').length;
  const activeModules = mockModules.filter(m => m.enabled).length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-semibold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Real-time operational overview</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Cameras</CardTitle>
            <Activity className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCameras}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {offlineCameras} offline
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Critical Alerts</CardTitle>
            <AlertTriangle className="w-4 h-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{criticalAlerts}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Last 24 hours
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Modules</CardTitle>
            <Shield className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeModules}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {mockModules.length - activeModules} disabled
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Events</CardTitle>
            <Users className="w-4 h-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAlerts.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Today
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Module Status */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Module Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {mockModules.map((module) => (
              <div
                key={module.id}
                className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border"
              >
                <div>
                  <div className="font-medium text-sm">{module.name}</div>
                  <div className="text-xs text-muted-foreground">{module.sensitivity}% sensitivity</div>
                </div>
                <Badge variant={module.enabled ? 'default' : 'secondary'}>
                  {module.enabled ? 'ON' : 'OFF'}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Camera Grid */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Live Camera Feeds</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockCameras.map((camera) => (
              <div
                key={camera.id}
                onClick={() => camera.status === 'active' && onCameraSelect(camera.id)}
                className={`group relative rounded-lg overflow-hidden border border-border ${
                  camera.status === 'active' ? 'cursor-pointer hover:border-primary/50' : 'opacity-60'
                }`}
              >
                <div className="aspect-video bg-secondary relative">
                  <img
                    src={camera.thumbnail}
                    alt={camera.name}
                    className="w-full h-full object-cover"
                  />
                  {camera.status === 'active' && (
                    <div className="absolute top-2 right-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    </div>
                  )}
                </div>
                <div className="p-3 bg-card">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium">{camera.name}</h4>
                      <p className="text-xs text-muted-foreground">{camera.location}</p>
                    </div>
                    <Badge variant={camera.status === 'active' ? 'default' : 'destructive'}>
                      {camera.status}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Alerts */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Recent Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockAlerts.slice(0, 5).map((alert) => (
              <div
                key={alert.id}
                className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 border border-border"
              >
                <img
                  src={alert.thumbnail}
                  alt={alert.message}
                  className="w-16 h-12 rounded object-cover"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        alert.severity === 'critical'
                          ? 'destructive'
                          : alert.severity === 'warning'
                          ? 'default'
                          : 'secondary'
                      }
                    >
                      {alert.severity}
                    </Badge>
                    <span className="font-medium">{alert.message}</span>
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {alert.cameraName} • {new Date(alert.timestamp).toLocaleTimeString()}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {alert.confidence && `${Math.round(alert.confidence * 100)}%`}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
