import { useState } from 'react';
import { ArrowLeft, Maximize2, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { mockCameras, mockModules } from '../data/mockData';
import type { Detection, DetectionModule } from '../types';

interface LiveViewProps {
  cameraId: string | null;
  onBack: () => void;
}

export function LiveView({ cameraId, onBack }: LiveViewProps) {
  const camera = mockCameras.find(c => c.id === cameraId);
  const [modules, setModules] = useState<DetectionModule[]>(mockModules);
  const [showModules, setShowModules] = useState(true);

  // Mock detections for demonstration
  const mockDetections: Detection[] = [
    {
      type: 'ppe',
      bbox: [0.15, 0.2, 0.35, 0.7],
      confidence: 0.94,
      label: 'Helmet Missing'
    },
    {
      type: 'ppe',
      bbox: [0.55, 0.25, 0.75, 0.65],
      confidence: 0.87,
      label: 'Safety Vest OK'
    },
    {
      type: 'face',
      bbox: [0.7, 0.15, 0.85, 0.35],
      confidence: 0.91,
      label: 'Person Detected'
    }
  ];

  const toggleModule = (moduleId: string) => {
    setModules(modules.map(m => 
      m.id === moduleId ? { ...m, enabled: !m.enabled } : m
    ));
  };

  const updateSensitivity = (moduleId: string, value: number) => {
    setModules(modules.map(m => 
      m.id === moduleId ? { ...m, sensitivity: value } : m
    ));
  };

  if (!camera) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Camera not found</p>
          <Button onClick={onBack} className="mt-4">Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border bg-card">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h2 className="font-semibold">{camera.name}</h2>
            <p className="text-sm text-muted-foreground">{camera.location}</p>
          </div>
          <Badge variant="default" className="bg-green-500">
            <div className="w-1.5 h-1.5 bg-white rounded-full mr-2 animate-pulse" />
            LIVE
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowModules(!showModules)}
          >
            {showModules ? 'Hide' : 'Show'} Modules
          </Button>
          <Button variant="outline" size="icon">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video Feed */}
        <div className="flex-1 flex items-center justify-center bg-black p-4">
          <div className="relative w-full h-full max-w-6xl max-h-full">
            {/* Video/Image */}
            <img
              src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=1200&h=800&fit=crop"
              alt="Live feed"
              className="w-full h-full object-contain"
            />

            {/* Detection Overlays */}
            <svg
              className="absolute inset-0 w-full h-full"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
            >
              {mockDetections.map((detection, index) => {
                const [x, y, x2, y2] = detection.bbox;
                const width = (x2 - x) * 100;
                const height = (y2 - y) * 100;
                const color = detection.label.includes('Missing') ? '#ef4444' : '#22c55e';

                return (
                  <g key={index}>
                    <rect
                      x={`${x * 100}%`}
                      y={`${y * 100}%`}
                      width={`${width}%`}
                      height={`${height}%`}
                      fill="none"
                      stroke={color}
                      strokeWidth="0.3"
                    />
                    <rect
                      x={`${x * 100}%`}
                      y={`${(y * 100) - 3}%`}
                      width={`${width}%`}
                      height="3%"
                      fill={color}
                      fillOpacity="0.9"
                    />
                    <text
                      x={`${(x * 100) + 0.5}%`}
                      y={`${(y * 100) - 1}%`}
                      fontSize="1.8"
                      fill="white"
                      fontWeight="500"
                    >
                      {detection.label} ({Math.round(detection.confidence * 100)}%)
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Info Overlay */}
            <div className="absolute bottom-4 left-4 flex gap-2">
              <div className="bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg text-white text-sm">
                FPS: 30
              </div>
              <div className="bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg text-white text-sm">
                Resolution: 1920x1080
              </div>
              <div className="bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg text-white text-sm">
                Detections: {mockDetections.length}
              </div>
            </div>
          </div>
        </div>

        {/* Modules Panel */}
        {showModules && (
          <div className="w-80 border-l border-border bg-card overflow-y-auto">
            <div className="p-4">
              <h3 className="font-semibold mb-4">Detection Modules</h3>
              <div className="space-y-4">
                {modules.map((module) => (
                  <Card key={module.id} className="p-4 bg-secondary/30 border-border">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium text-sm mb-1">{module.name}</h4>
                        <p className="text-xs text-muted-foreground">{module.description}</p>
                      </div>
                      <Switch
                        checked={module.enabled}
                        onCheckedChange={() => toggleModule(module.id)}
                      />
                    </div>
                    {module.enabled && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Sensitivity</span>
                          <span className="font-medium">{module.sensitivity}%</span>
                        </div>
                        <Slider
                          value={[module.sensitivity]}
                          onValueChange={([value]) => updateSensitivity(module.id, value)}
                          min={0}
                          max={100}
                          step={5}
                          className="w-full"
                        />
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
