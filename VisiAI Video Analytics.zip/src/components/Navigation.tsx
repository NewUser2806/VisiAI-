import { Video, AlertTriangle, BarChart3, Settings, LayoutDashboard, Cable } from 'lucide-react';
import type { Screen } from '../App';

interface NavigationProps {
  currentScreen: Screen;
  onNavigate: (screen: Screen) => void;
}

export function Navigation({ currentScreen, onNavigate }: NavigationProps) {
  const navItems = [
    { id: 'dashboard' as Screen, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'live' as Screen, label: 'Live View', icon: Video },
    { id: 'alerts' as Screen, label: 'Alerts', icon: AlertTriangle },
    { id: 'analytics' as Screen, label: 'Analytics', icon: BarChart3 },
    { id: 'cameras' as Screen, label: 'Cameras', icon: Settings },
    { id: 'integration' as Screen, label: 'Camera Integration', icon: Cable },
  ];

  const handleNavigate = (screen: Screen) => {
    console.log('Navigating to:', screen);
    onNavigate(screen);
  };

  return (
    <nav className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Video className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-sidebar-foreground">VisiAI</h1>
            <p className="text-xs text-muted-foreground">Video Analytics</p>
          </div>
        </div>
      </div>

      <div className="flex-1 px-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-1 transition-colors ${
                isActive
                  ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="p-4 border-t border-sidebar-border">
        <div className="text-xs text-muted-foreground">
          System Status: <span className="text-green-500">●</span> Online
        </div>
      </div>
    </nav>
  );
}