import type { Camera, Alert, DetectionModule, Zone } from '../types';

export const mockCameras: Camera[] = [
  {
    id: 'cam-1',
    name: 'Entrance Gate',
    location: 'Main Entrance',
    status: 'active',
    rtspUrl: 'rtsp://example.com/cam1',
    zone: 'zone-1',
    thumbnail: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop'
  },
  {
    id: 'cam-2',
    name: 'Warehouse Floor',
    location: 'Building A',
    status: 'active',
    rtspUrl: 'rtsp://example.com/cam2',
    zone: 'zone-2',
    thumbnail: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=400&h=300&fit=crop'
  },
  {
    id: 'cam-3',
    name: 'Loading Dock',
    location: 'Building B',
    status: 'active',
    rtspUrl: 'rtsp://example.com/cam3',
    zone: 'zone-2',
    thumbnail: 'https://images.unsplash.com/photo-1553413077-190dd305871c?w=400&h=300&fit=crop'
  },
  {
    id: 'cam-4',
    name: 'Parking Area',
    location: 'Outdoor',
    status: 'offline',
    rtspUrl: 'rtsp://example.com/cam4',
    zone: 'zone-3',
    thumbnail: 'https://images.unsplash.com/photo-1506521781263-d8422e82f27a?w=400&h=300&fit=crop'
  },
  {
    id: 'cam-5',
    name: 'Office Corridor',
    location: 'Floor 2',
    status: 'active',
    rtspUrl: 'rtsp://example.com/cam5',
    zone: 'zone-3',
    thumbnail: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=400&h=300&fit=crop'
  },
  {
    id: 'cam-6',
    name: 'Server Room',
    location: 'Floor 1',
    status: 'active',
    rtspUrl: 'rtsp://example.com/cam6',
    zone: 'zone-1',
    thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=300&fit=crop'
  }
];

export const mockAlerts: Alert[] = [
  {
    id: 'alert-1',
    cameraId: 'cam-2',
    cameraName: 'Warehouse Floor',
    type: 'ppe',
    severity: 'critical',
    message: 'Helmet Missing',
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    thumbnail: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=200&h=150&fit=crop',
    confidence: 0.94
  },
  {
    id: 'alert-2',
    cameraId: 'cam-1',
    cameraName: 'Entrance Gate',
    type: 'intrusion',
    severity: 'critical',
    message: 'Intrusion Detected',
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    thumbnail: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=200&h=150&fit=crop',
    confidence: 0.89
  },
  {
    id: 'alert-3',
    cameraId: 'cam-6',
    cameraName: 'Server Room',
    type: 'face',
    severity: 'warning',
    message: 'Unauthorized Person',
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=200&h=150&fit=crop',
    confidence: 0.87
  },
  {
    id: 'alert-4',
    cameraId: 'cam-3',
    cameraName: 'Loading Dock',
    type: 'loitering',
    severity: 'warning',
    message: 'Loitering Detected',
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    thumbnail: 'https://images.unsplash.com/photo-1553413077-190dd305871c?w=200&h=150&fit=crop',
    confidence: 0.76
  },
  {
    id: 'alert-5',
    cameraId: 'cam-2',
    cameraName: 'Warehouse Floor',
    type: 'ppe',
    severity: 'warning',
    message: 'Safety Vest Missing',
    timestamp: new Date(Date.now() - 45 * 60 * 1000),
    thumbnail: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=200&h=150&fit=crop',
    confidence: 0.82
  },
  {
    id: 'alert-6',
    cameraId: 'cam-5',
    cameraName: 'Office Corridor',
    type: 'crowd',
    severity: 'info',
    message: 'High Occupancy',
    timestamp: new Date(Date.now() - 60 * 60 * 1000),
    thumbnail: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=200&h=150&fit=crop',
    confidence: 0.91
  }
];

export const mockModules: DetectionModule[] = [
  {
    id: 'module-1',
    name: 'PPE Detection',
    type: 'ppe',
    enabled: true,
    sensitivity: 75,
    description: 'Detects helmet, vest, and mask compliance'
  },
  {
    id: 'module-2',
    name: 'Intrusion Detection',
    type: 'intrusion',
    enabled: true,
    sensitivity: 85,
    description: 'Alerts on unauthorized zone access'
  },
  {
    id: 'module-3',
    name: 'Loitering Detection',
    type: 'loitering',
    enabled: true,
    sensitivity: 60,
    description: 'Detects prolonged presence in areas'
  },
  {
    id: 'module-4',
    name: 'Face Detection',
    type: 'face',
    enabled: true,
    sensitivity: 70,
    description: 'Recognizes authorized personnel'
  },
  {
    id: 'module-5',
    name: 'Crowd Density',
    type: 'crowd',
    enabled: false,
    sensitivity: 65,
    description: 'Monitors occupancy and density'
  },
  {
    id: 'module-6',
    name: 'Behavior Analysis',
    type: 'behavior',
    enabled: false,
    sensitivity: 55,
    description: 'Detects anomalous behavior patterns'
  }
];

export const mockZones: Zone[] = [
  {
    id: 'zone-1',
    name: 'Restricted Area',
    type: 'restricted',
    cameras: ['cam-1', 'cam-6']
  },
  {
    id: 'zone-2',
    name: 'Warehouse Zone',
    type: 'monitored',
    cameras: ['cam-2', 'cam-3']
  },
  {
    id: 'zone-3',
    name: 'Public Area',
    type: 'public',
    cameras: ['cam-4', 'cam-5']
  }
];
