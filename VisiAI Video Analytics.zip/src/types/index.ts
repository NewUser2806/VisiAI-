export interface Camera {
  id: string;
  name: string;
  location: string;
  status: 'active' | 'offline';
  rtspUrl: string;
  zone?: string;
  thumbnail: string;
}

export interface Alert {
  id: string;
  cameraId: string;
  cameraName: string;
  type: 'ppe' | 'intrusion' | 'loitering' | 'face' | 'crowd' | 'behavior';
  severity: 'critical' | 'warning' | 'info';
  message: string;
  timestamp: Date;
  thumbnail: string;
  confidence?: number;
}

export interface DetectionModule {
  id: string;
  name: string;
  type: 'ppe' | 'intrusion' | 'loitering' | 'face' | 'crowd' | 'behavior';
  enabled: boolean;
  sensitivity: number;
  description: string;
}

export interface Detection {
  type: string;
  bbox: [number, number, number, number];
  confidence: number;
  label: string;
}

export interface Zone {
  id: string;
  name: string;
  type: 'restricted' | 'monitored' | 'public';
  cameras: string[];
}
